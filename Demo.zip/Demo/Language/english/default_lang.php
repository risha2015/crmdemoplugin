<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["demo"] = "Demo";
$lang["demo_hello_world"] = "Hello World!";

return $lang;
